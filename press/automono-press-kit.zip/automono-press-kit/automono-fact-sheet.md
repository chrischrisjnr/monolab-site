# Automono press kit



**One line:** One shot. Two photos. Shoot in color with your iPhone Camera, and Automono adds a black and white print beside it.

**100-word description**

> Automono is a darkroom for the iPhone. There's no new camera to learn: you keep shooting with the built-in Camera app, and Automono develops a black and white print of each photo, then files it beside the untouched color original. Prints are made from the best data the iPhone saved, ProRAW included, as full-resolution 10-bit files that keep the original's date and place. Choose from four film stocks, Soft 50, Platinum 100, Classic 125 and Noir 400, and set the grain from clean to heavy. A one-minute Shortcuts automation makes it run in the background. Everything happens on the device. No account, no uploads. Free.

**Bio**

> Chris is a designer in Melbourne who runs Tuna Studio, a small strategic design studio. Chris has shot black and white on a Fujifilm X100F for years and built Automono to make the iPhone work the same way.

**Contact:** chris@tuna.studio

**Fact sheet**

| | |
| 
Images in this kit may be used to write about Automono. Photo pairs are sample images processed by Automono.
